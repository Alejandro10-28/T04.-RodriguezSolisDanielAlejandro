﻿using System;

namespace Conversion_C
{
    class Program
    {
        static void Main(string[] args)
        {
            //Se instancia la clase principal para mandar a llamar el menú.
            Principal M = new Principal();
            M.Menu();
          
                

        }
    }
}
